Folders are configured using the Config tab and can be added from
	recent (by double click with parent selected)
	by drag / drop into recent (of Folder / Folder Shortcut)
	from Clipboard (as Folder / Text)
and renamed by hitting F2 (Ctrl + F2 to edit other properties)

Then you can launch folder shortcuts in 3 ways
Click them from the View tab
Search for them in the Search tab
See them in the menu (later in the system tray itself)

A Favorite is a folder that appears in the Menu itself so you can easily look for new folders
(This is similar to the Computer Menu)

Glossary:
Computer and Favorites are menus that are populated by current explorer stuff

Faves are Items with a CheckBox and appear as menus
